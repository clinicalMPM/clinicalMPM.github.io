
%-----------------------------------------------------------------------
% Create hMRI Maps - Batch options for UNICORT correction
%-----------------------------------------------------------------------
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.output.outdir = {folder_path};
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.sensitivity.RF_us = '-';
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.b1_type.UNICORT.b1parameters.b1metadata = 'yes';
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.raw_mpm.MT = mtinputs;
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.raw_mpm.PD = pdinputs;
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.raw_mpm.T1 = t1inputs;
matlabbatch{1}.spm.tools.hmri.create_mpm.subj.popup = false;
